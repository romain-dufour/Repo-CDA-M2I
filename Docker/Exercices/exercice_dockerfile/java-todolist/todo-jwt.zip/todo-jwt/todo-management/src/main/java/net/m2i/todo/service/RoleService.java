package net.m2i.todo.service;

import net.m2i.todo.entity.Role;

import java.util.List;

public interface RoleService {

    List<Role> getAllRole();

}
