import React from 'react'

const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <p className='text-center'>Copyrights Mohamed pour M2i</p>
        </footer>
    </div>
  )
}

export default FooterComponent