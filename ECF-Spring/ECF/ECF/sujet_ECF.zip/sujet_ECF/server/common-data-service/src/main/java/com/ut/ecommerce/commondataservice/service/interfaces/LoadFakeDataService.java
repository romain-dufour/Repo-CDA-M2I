package com.ut.ecommerce.commondataservice.service.interfaces;

public interface LoadFakeDataService {

    boolean loadTestData();
}

